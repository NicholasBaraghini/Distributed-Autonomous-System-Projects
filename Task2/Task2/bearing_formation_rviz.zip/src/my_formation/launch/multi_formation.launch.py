from launch import LaunchDescription
from launch_ros.actions import Node
import numpy as np
import networkx as nx
import os
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    MAXITERS = 8000  # Max iterations
    COMM_TIME = 1e-3  # communication time period

    ################################ CHOOSE THE FORMATION ####################################
    '''                                 LIST of formation: 
    key word: 'square' ---> square that change its shape in a turbot
    key word: 'octagon ----> octagon that shuffle position of the followers
    key word: 'DA' ---> sequence of letter to compose D - A
    '''
    FORMATION = 'DA'  # chose the pattern formation

    n_x = 2  # dimension of vector state
    space_dimension = 2  # dimension of the space where the agents evolve their dynamics
    dim_x = n_x * space_dimension  # number of elements of the vector state

    # Control Parameters
    kp = 100
    kv = 50

    # Dictionary of Pattern Formation
    PatternForm = {
        "square": {"N_Agents": 4,
                   "N_Leaders": 2,
                   "Position1": [[0, 1], [1, 0], [1, 1], [0, 0]],
                   "Position2": [[0.33, 0.66], [0.66, 0.33],  [1, 1], [0, 0]],
                   "Adj": np.array([[0, 1, 1, 1],
                                    [1, 0, 1, 0],
                                    [1, 1, 0, 1],
                                    [1, 0, 1, 0]])
                   },

        "octagon": {"N_Agents": 8,
                    "N_Leaders": 3,
                    "Position1": [[0, 0.4], [0.8, 0], [0, 0.8], [0.8, 1.2], [1.2, 0.8], [0.4, 1.2], [1.2, 0.4],
                                 [0.4, 0]],
                    "Position2":[[0.8, 0],[0, 0.8],[1.2, 0.8], [0, 0.4],[0.8, 1.2], [0.4, 1.2], [1.2, 0.4],
                     [0.4, 0]],
                    "Adj": np.array([[0, 1, 0, 1, 0, 1, 0, 1],
                                     [1, 0, 1, 0, 1, 0, 1, 0],
                                     [0, 1, 0, 1, 0, 1, 0, 1],
                                     [1, 0, 1, 0, 1, 0, 1, 0],
                                     [0, 1, 0, 1, 0, 1, 0, 1],
                                     [1, 0, 1, 0, 1, 0, 1, 0],
                                     [0, 1, 0, 1, 0, 1, 0, 1],
                                     [1, 0, 1, 0, 1, 0, 1, 0]])
                    },

        "DA": {"N_Agents": 9,
                "N_Leaders": 3,
                "Position1": [[2, 0], [0, 1.4], [2.8, 0.8], [2.8, 3.2], [2, 4.4], [0, 4.4],[2.8, 2], [0, 3], [0, 0]],
                "Position2": [[2.8, 0], [1.75, 2], [1, 2], [0, 2], [1.5, 4.4], [2.8, 3], [2.8, 2], [0, 3], [0, 0]],
                "Adj": np.array([[0, 1, 1, 1, 1, 1, 1, 1, 1],
                                 [1, 0, 1, 1, 1, 1, 1, 1, 1],
                                 [1, 1, 0, 1, 1, 1, 1, 1, 1],
                                 [1, 1, 1, 0, 1, 1, 1, 1, 1],
                                 [1, 1, 1, 1, 0, 1, 1, 1, 1],
                                 [1, 1, 1, 1, 1, 0, 1, 1, 1],
                                 [1, 1, 1, 1, 1, 1, 0, 1, 1],
                                 [1, 1, 1, 1, 1, 1, 1, 0, 1],
                                 [1, 1, 1, 1, 1, 1, 1, 1, 0]])
                }
    }

    # extract the parameters from the pattern chosen
    N_AGENTS = PatternForm[FORMATION]["N_Agents"]
    N_LEADERS = PatternForm[FORMATION]["N_Leaders"]
    N_FOLLOWERS = N_AGENTS - N_LEADERS
    Position1 = PatternForm[FORMATION]["Position1"]
    Position2 = PatternForm[FORMATION]["Position2"]
    Adj = PatternForm[FORMATION]["Adj"]

    # Define Init values
    x_init = np.random.randint(2, 4) * np.random.rand(dim_x * N_AGENTS, 1)

    launch_description = []  # append here your nodes

    ################################################################################
    # RVIZ
    ################################################################################

    # initialize launch description with rviz executable
    rviz_config_dir = get_package_share_directory('my_formation')
    rviz_config_file = os.path.join(rviz_config_dir, 'rviz_config.rviz')

    launch_description.append(
        Node(
            package='rviz2',
            executable='rviz2',
            arguments=['-d', rviz_config_file],
            # output='screen',
            # prefix='xterm -title "rviz2" -hold -e'
        ))

    ################################################################################


    for ii in range(N_AGENTS):
        N_ii = np.nonzero(Adj[:, ii])[0].tolist()  # neighbours
        print(f'Neighbours of {ii} are: {N_ii}\n')

        # create a list of indexes where the elements of the state can be found in the state structure
        ii_index = ii * dim_x + np.arange(dim_x)
        # extract the state elements of state of agent ii
        x_init_ii = x_init[ii_index].flatten().tolist()

        # all the agents will start with zero velocity
        x_init_ii[2] = 0
        x_init_ii[3] = 0

        # for each leader: NB-The leaders are considered as the last agents of the list of agents!
        if ii >= N_FOLLOWERS:
            Agent_role = 'leader'

            # The leader will start from the desired position and will maintain a velocity null
            x_init_ii[0] = Position1[ii][0]
            x_init_ii[1] = Position1[ii][1]
            x_init_ii = np.asarray(x_init_ii)
            # Flatten
            x_init_ii = x_init_ii.flatten().tolist()

        else:
            Agent_role = 'follower'

        # Convert the desired position structure as an array and then flatten everything
        Position1 = np.asarray(Position1)
        Position2 = np.asarray(Position2)
        Target_Pos1 = Position1.flatten().tolist()
        Target_Pos2 = Position2.flatten().tolist()
        Adj_matrix = Adj.flatten().tolist()

        launch_description.append(
            Node(
                package='my_formation',
                namespace='agent_{}'.format(ii),
                executable='mf_agent_i',
                parameters=[{
                    'agent_id': ii,
                    'max_iters': MAXITERS,
                    'communication_time': COMM_TIME,
                    'x_init': x_init_ii,
                    'neigh': N_ii,
                    'kp': kp,
                    'kv': kv,
                    'Target_Pos1': Target_Pos1,
                    'Target_Pos2': Target_Pos2,
                    'type': Agent_role,
                    'N_AGENTS': N_AGENTS
                }],
                output='screen',
                prefix='xterm -title "agent_{}" -hold -e'.format(ii)
            )
        )

        # RVIZ
        launch_description.append(
            Node(
                package='my_formation',
                namespace='agent_{}'.format(ii),
                executable='visualizer',
                parameters=[{
                    'agent_id': ii,
                    'communication_time': COMM_TIME,
                    'N_FOLLOWERS': N_FOLLOWERS
                }],
            ))


    return LaunchDescription(launch_description)

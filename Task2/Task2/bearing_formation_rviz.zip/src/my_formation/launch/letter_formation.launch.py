from launch import LaunchDescription
from launch_ros.actions import Node
import numpy as np
import networkx as nx
import os
import os
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    MAXITERS = 5000  # Max iterations
    COMM_TIME = 1e-2  # communication time period


    ################################ CHOOSE THE FORMATION ####################################
    '''                                 LIST of formation: 
    key word: 'square' ---> square translating on x and then in diagonal
    key word: 'S_translating' ---> S letter translating on x and then in diagonal
    key word: 'DAS' ---> sequence of letter to compose word DAS
    '''
    FORMATION = 'P_translating'  # chose the pattern formation

    n_x = 3  # dimension of vector state
    space_dimension = 2  # dimension of the space where the agents evolve their dynamics
    dim_x = n_x * space_dimension  # number of elements of the vector state

    # Control Parameters
    kp = 25
    kv = 85

    # Dictionary of Pattern Formation
    PatternForm = {
        "square": {"N_Agents": 4,
                   "N_Leaders": 2,
                   "Position_1": [[0, 0], [1, 0], [1, 1], [0, 1]],
                   "Position_2": [[1, 0], [2, 0], [2, 1], [1, 1]],
                   "Position_3": [[2, 1], [3, 1], [3, 2], [2, 2]],
                   "Adj": np.array([[0, 1, 1, 1],
                                    [1, 0, 1, 0],
                                    [1, 1, 0, 1],
                                    [1, 0, 1, 0]])
                   },


        "S_translating": {"N_Agents": 9,
                "N_Leaders": 3,
                "Position_1": [[0, 0], [1.5, 0], [2.7, 0.75], [1.5, 2.35], [0, 2.8], [0, 3.8], [1.4, 4.5], [2.4, 4.5], [2.7, 1.95]],
                "Position_2": [[1, 0], [2.5, 0], [3.7, 0.75], [2.5, 2.35], [1, 2.8], [1, 3.8], [2.4, 4.5], [3.4, 4.5], [3.7, 1.95]],
                "Position_3": [[2, 1], [3.5, 1], [4.7, 1.75], [3.5, 3.35], [2, 3.8], [2, 4.8], [3.4, 5.5], [4.4, 5.5], [4.7, 2.95]],
                "Adj": np.array([[0, 1, 1, 0, 1, 1, 1, 1, 1],
                                 [1, 0, 1, 1, 1, 0, 1, 1, 1],
                                 [1, 1, 0, 1, 1, 1, 0, 1, 1],
                                 [0, 1, 1, 0, 1, 1, 1, 1, 0],
                                 [1, 1, 1, 1, 0, 1, 1, 1, 1],
                                 [1, 0, 1, 1, 1, 0, 1, 1, 0],
                                 [1, 1, 0, 1, 1, 1, 0, 1, 1],
                                 [1, 1, 1, 1, 1, 1, 1, 0, 1],
                                 [1, 1, 1, 0, 1, 0, 1, 1, 0]])
                },

        "P_translating": {"N_Agents": 8,
                          "N_Leaders": 3,
                          "Position_1": [[0, 0.5], [0, 1], [0, 1.5], [0.5, 2], [1, 1.5], [0.5, 1], [0, 2],
                                          [0, 0]],
                          "Position_2": [[0, 1], [0, 2], [0, 3], [1, 4], [2, 3], [1, 2], [0, 4],
                                          [0, 0]],
                          "Position_3": [[2, 1], [2, 2], [2, 3], [3, 4], [4, 3], [3, 2], [2, 4],
                                          [2, 0]],
                          "Adj": np.array([[0, 1, 1, 0, 1, 1, 1, 1],
                                           [1, 0, 1, 1, 1, 0, 1, 1],
                                           [1, 1, 0, 1, 1, 1, 0, 1],
                                           [0, 1, 1, 0, 1, 1, 1, 1],
                                           [1, 1, 1, 1, 0, 1, 1, 1],
                                           [1, 0, 1, 1, 1, 0, 1, 1],
                                           [1, 1, 0, 1, 1, 1, 0, 1],
                                           [1, 1, 1, 1, 1, 1, 1, 0]])
                          },

        "DAS": {"N_Agents": 9,
                "N_Leaders": 3,
                "Position_1": [[2, 0], [0, 1.4], [2.8, 0.8], [2.8, 2], [2.8, 3.2], [2, 4.4], [0, 4.4], [0, 3], [0, 0]],
                "Position_2": [[0, 0], [2.8, 0], [2.8, 2], [1.4, 2], [0, 2], [0, 3.2], [0.8, 4.4], [2, 4.4],
                               [2.8, 3.2]],
                "Position_3": [[0, 0], [1.5, 0], [2.7, 0.75], [1.5, 2.35], [0, 2.8], [0, 3.8], [1.4, 4.5],
                               [2.4, 4.5], [2.7, 1.95]],
                "Adj": np.array([[0, 1, 1, 0, 1, 1, 1, 1, 1],
                                 [1, 0, 1, 1, 1, 0, 1, 1, 1],
                                 [1, 1, 0, 1, 1, 1, 0, 1, 1],
                                 [0, 1, 1, 0, 1, 1, 1, 1, 0],
                                 [1, 1, 1, 1, 0, 1, 1, 1, 1],
                                 [1, 0, 1, 1, 1, 0, 1, 1, 0],
                                 [1, 1, 0, 1, 1, 1, 0, 1, 1],
                                 [1, 1, 1, 1, 1, 1, 1, 0, 1],
                                 [1, 1, 1, 0, 1, 0, 1, 1, 0]])
                },
    }

    # extract the parameters from the pattern chosen
    N_AGENTS = PatternForm[FORMATION]["N_Agents"]
    N_LEADERS = PatternForm[FORMATION]["N_Leaders"]
    N_FOLLOWERS = N_AGENTS - N_LEADERS
    Position_1 = PatternForm[FORMATION]["Position_1"]
    Position_2 = PatternForm[FORMATION]["Position_2"]
    Position_3 = PatternForm[FORMATION]["Position_3"]
    Adj = PatternForm[FORMATION]["Adj"]

    # Define Init values
    x_init = np.random.randint(2, 4) * np.random.rand(dim_x * N_AGENTS, 1)

    launch_description = []  # append here your nodes

    
    ################################################################################
    # RVIZ
    ################################################################################

    # initialize launch description with rviz executable
    rviz_config_dir = get_package_share_directory('my_formation')
    rviz_config_file = os.path.join(rviz_config_dir, 'rviz_config.rviz')

    launch_description.append(
        Node(
            package='rviz2',
            executable='rviz2',
            arguments=['-d', rviz_config_file],
            # output='screen',
            # prefix='xterm -title "rviz2" -hold -e'
        ))

    ################################################################################
    
    

    for ii in range(N_AGENTS):
        N_ii = np.nonzero(Adj[:, ii])[0].tolist()  # neighbours
        print(f'Neighbours of {ii} are: {N_ii}\n')

        # create a list of indexes where the elements of the state can be found in the state structure
        ii_index = ii * dim_x + np.arange(dim_x)
        # extract the state elements of state of agent ii
        x_init_ii = x_init[ii_index].flatten().tolist()

        # all the agents will start with zero velocity
        x_init_ii[2] = 0
        x_init_ii[3] = 0
        x_init_ii[4] = 0
        x_init_ii[5] = 0

        # for each leader: NB-The leaders are considered as the last agents of the list of agents!
        if ii >= N_FOLLOWERS:
            Agent_role = 'leader'
        else:
            Agent_role = 'follower'

        # Convert the desired position structure as an array and then flatten everything
        Position_1 = np.asarray(Position_1)
        Position_2 = np.asarray(Position_2)
        Position_3 = np.asarray(Position_3)

        Target_Pos_1 = Position_1.flatten().tolist()
        Target_Pos_2 = Position_2.flatten().tolist()
        Target_Pos_3 = Position_3.flatten().tolist()

        Adj_matrix = Adj.flatten().tolist()

        launch_description.append(
            Node(
                package='my_formation',
                namespace='agent_{}'.format(ii),
                executable='agent_i',
                parameters=[{
                    'agent_id': ii,
                    'max_iters': MAXITERS,
                    'communication_time': COMM_TIME,
                    'x_init': x_init_ii,
                    'neigh': N_ii,
                    'kp': kp,
                    'kv': kv,
                    'Target_Pos_1': Target_Pos_1,
                    'Target_Pos_2': Target_Pos_2,
                    'Target_Pos_3': Target_Pos_3,
                    'type': Agent_role,
                    'N_AGENTS': N_AGENTS,
                    'N_FOLLOWERS': N_FOLLOWERS
                }],
                output='screen',
                prefix='xterm -title "agent_{}" -hold -e'.format(ii)
                ))

        # RVIZ
        launch_description.append(
            Node(
                package='my_formation',
                namespace='agent_{}'.format(ii),
                executable='visualizer',
                parameters=[{
                    'agent_id': ii,
                    'communication_time': COMM_TIME,
                    'N_FOLLOWERS' : N_FOLLOWERS
                }],
		    ))

    
    return LaunchDescription(launch_description)

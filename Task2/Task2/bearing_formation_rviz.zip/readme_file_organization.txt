############### DESCRIPTION OF THE FILE IN THE FOLDER ############

In the src folder there are several launcher, one for each configuration and with different goal. each launcher is linked to a different code for the agent, depennding on the purpose (the structure of the different agent_i is the same).
To change formation, change key of pattern selector in the launcher
To easier the code lecture, a brief description of each launcher and the relative agents code.

#1
multi_formation.launch.py---> launcher for formation that change position of the followers in time. composed a square(4 agents), octagon(8 agents), sequence D-A (9 agents). static leaders
mf_agent_i ----> node to implement the control law for constant (zero) leader velocity and two formation

#2
letter_formation.launch----> launcher for formation that deals with timevarying leader velocity. compose a square, S that translate (9 agents), word DAS (9 agents). moving leaders
letter_formation_control---> node to implement the control law fortime varying leader velocity and different formation/position in space



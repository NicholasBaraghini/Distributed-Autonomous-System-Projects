############### DESCRIPTION OF THE FILE IN THE FOLDER ############

In the src folder there are several launcher, one for each configuration and with different goal. each launcher is linked to a different code for the agent, depennding on the purpose (the structure of the different agent_i is the same).
To easier the code lecture, a brief description of each launcher and the relative agents code.

#1
my_formation.launch.py ---> launcher for simple static formation of square( 4 agents), octagon (8 agents). static leaders
agent_i ---> node to implement the control law for constant (zero) leader velocity and single formation

#2
multi_formation.launch.py---> launcher for formation that change position of the followers in time. composed a square(4 agents), octagon(8 agents), sequence D-A (9 agents). static leaders
mf_agent_i ----> node to implement the control law for constant (zero) leader velocity and two formation

#3
letter_formation.launch----> launcher for formation that deals with timevarying leader velocity. compose a square, S that translate (9 agents), word DAS (9 agents). moving leaders
letter_formation_control---> node to implement the control law fortime varying leader velocity and different formation/position in space

!!!!NOTE!!!!!
This code automaticly plot csv_file at the end of iteration but need to insert the path to csv_file 
 at line 16 of plot_csv.py insert path to /letter_csv_file
 at line 16 of mf_plot_csv.py insert path to /mf_csv_file
 at line 16 of letter_plot_csv.py insert path to /_csv_file

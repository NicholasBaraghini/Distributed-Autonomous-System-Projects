from launch import LaunchDescription
from launch_ros.actions import Node
import numpy as np
import networkx as nx
import os


# from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    MAXITERS = 4000  # Max iterations
    COMM_TIME = 1e-3  # communication time period
	
     ################################ CHOOSE THE FORMATION ####################################
    '''                                 LIST of formation: 
    key word: 'square' ---> square formation
    key word: 'octagon ----> octagon formation
    '''
    FORMATION = 'square'  # chose the pattern formation

    n_x = 2  # dimension of vector state
    space_dimension = 2  # dimension of the space where the agents evolve their dynamics
    dim_x = n_x * space_dimension  # number of elements of the vector state

    # Control Parameters
    kp = 100
    kv = 50

    # Dictionary of Pattern Formation
    PatternForm = {
        "square": {"N_Agents": 4,
                   "N_Leaders": 2,
                   "Position": [[0, 0], [1, 0], [1, 1], [0, 1]],
                   "Adj": np.array([[0, 1, 1, 1],
                                    [1, 0, 1, 0],
                                    [1, 1, 0, 1],
                                    [1, 0, 1, 0]])
                   },



        "octagon": {"N_Agents": 8,
                    "N_Leaders": 3,
                    "Position": [[0, 0.4], [0.8, 0], [0, 0.8], [0.8, 1.2], [1.2, 0.8], [0.4, 1.2], [1.2, 0.4],
                                 [0.4, 0]],  # , [0.5, 0], [1, 0.5], [0.5, 1], [0, 0.5]],
                    "Adj": np.array([[0, 1, 0, 1, 0, 1, 0, 1],
                                     [1, 0, 1, 0, 1, 0, 1, 0],
                                     [0, 1, 0, 1, 0, 1, 0, 1],
                                     [1, 0, 1, 0, 1, 0, 1, 0],
                                     [0, 1, 0, 1, 0, 1, 0, 1],
                                     [1, 0, 1, 0, 1, 0, 1, 0],
                                     [0, 1, 0, 1, 0, 1, 0, 1],
                                     [1, 0, 1, 0, 1, 0, 1, 0]])
                    }
    }

    # extract the parameters from the pattern chosen
    N_AGENTS = PatternForm[FORMATION]["N_Agents"]
    N_LEADERS = PatternForm[FORMATION]["N_Leaders"]
    N_FOLLOWERS = N_AGENTS - N_LEADERS
    Position = PatternForm[FORMATION]["Position"]
    Adj = PatternForm[FORMATION]["Adj"]

    # Define Init values
    x_init = np.random.randint(2, 4) * np.random.rand(dim_x * N_AGENTS, 1)

    launch_description = []  # append here your nodes

    for ii in range(N_AGENTS):
        N_ii = np.nonzero(Adj[:, ii])[0].tolist()  # neighbours
        print(f'Neighbours of {ii} are: {N_ii}\n')

        # create a list of indexes where the elements of the state can be found in the state structure
        ii_index = ii * dim_x + np.arange(dim_x)
        # extract the state elements of state of agent ii
        x_init_ii = x_init[ii_index].flatten().tolist()

        # all the agents will start with zero velocity
        x_init_ii[2] = 0
        x_init_ii[3] = 0

        # for each leader: NB-The leaders are considered as the last agents of the list of agents!
        if ii >= N_FOLLOWERS:
            Agent_role = 'leader'

            # The leader will start from the desired position and will maintain a velocity null
            x_init_ii[0] = Position[ii][0]
            x_init_ii[1] = Position[ii][1]
            x_init_ii = np.asarray(x_init_ii)
            # Flatten
            x_init_ii = x_init_ii.flatten().tolist()

        else:
            Agent_role = 'follower'

        # Convert the desired position structure as an array and then flatten everything
        Position = np.asarray(Position)
        Target_Pos = Position.flatten().tolist()
        Adj_matrix = Adj.flatten().tolist()
        
        launch_description.append(
            Node(
                package='my_formation_control',
                namespace='agent_{}'.format(ii),
                executable='agent_i',
                parameters=[{
                    'agent_id': ii,
                    'max_iters': MAXITERS,
                    'communication_time': COMM_TIME,
                    'x_init': x_init_ii,
                    'neigh': N_ii,
                    'kp': kp,
                    'kv': kv,
                    'Target_Pos': Target_Pos,
                    'type': Agent_role,
                    'N_AGENTS': N_AGENTS
                }],
                output='screen',
                prefix='xterm -title "agent_{}" -hold -e'.format(ii)
            )
        )

    launch_description.append(
        Node(
            package='my_formation_control',
            namespace='PLOTTING_AGENT',
            executable='plot_csv',
            parameters=[{
                'max_iters': MAXITERS,
                'communication_time': COMM_TIME,
                'Adj_matrix': Adj_matrix,
                'Target_Pos': Target_Pos,
                'N_AGENTS': N_AGENTS
            }],
            output='screen',
            prefix='xterm -title "PLOTTING AGENT" -hold -e'
        )
    )

    return LaunchDescription(launch_description)

from time import sleep
import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray as msg_float

import numpy as np
import matplotlib.pyplot as plt
import signal
import os


def PlotCsv(Adj, Position):
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    _, _, files = next(os.walk("/home/federico/DAS_ros2_files/ROS2_bearing_formation/_csv_file"))
    NN = len(files)

    xx_csv = {}
    Tlist = []

    for ii in range(NN):
        xx_csv[ii] = np.genfromtxt("_csv_file/agent_{}.csv".format(ii), delimiter=',').T
        Tlist.append(xx_csv[ii].shape[1])

    n_x = int((xx_csv[ii].shape[0]) / 2)
    print(n_x)
    Tmax = min(Tlist)

    xx = np.zeros((NN * n_x, Tmax))
    err = np.zeros((NN * n_x, Tmax))


    Adj = np.asarray(Adj)

    for ii in range(NN):
        for jj in range(n_x):
            index_ii = ii * n_x + jj
            xx[index_ii, :] = xx_csv[ii][jj][:Tmax]  # useful to remove last samples
        err[ii:ii + 2, :] = np.abs(xx[ii * n_x:(ii * n_x) + 2, :] - np.array(Position[ii]).reshape(2, 1))

    plt.figure()
    for e in err:
        plt.plot(range(Tmax), e)
        plt.grid()
        plt.xlabel('$t$', fontsize=16)
        plt.ylabel('$||x_i^t-x_j^t||, i = 1,...,N$', fontsize=16)
        plt.title('Position Error of each agent', fontsize=12)

    block_var = False if n_x < 3 else True
    plt.show(block=block_var)

    if 1 and n_x == 2:  # animation
        plt.figure()
        dt = 100  # sub-sampling of the plot horizon
        for tt in range(0, Tmax, dt):
            xx_tt = xx[:, tt].T
            for ii in range(NN):
                for jj in range(NN):
                    index_ii = ii * n_x + np.arange(n_x)
                    xx_ii = xx_tt[index_ii]
                    p_prev = xx_tt[index_ii]
                    plt.plot(xx_ii[0], xx_ii[1], marker='o', markersize=15, fillstyle='none', color='tab:red')
                   
                    if Adj[ii, jj] & (jj > ii):
                        index_jj = (jj % NN) * n_x + np.array(range(n_x))
                        p_curr = xx_tt[index_jj]
                        plt.plot([p_prev[0], p_curr[0]], [p_prev[1], p_curr[1]],
                                 linewidth=2, color='tab:blue', linestyle='solid')

            axes_lim = (np.min(xx) - 1, np.max(xx) + 1)
            plt.xlim(axes_lim)
            plt.ylim(axes_lim)
            plt.xlabel('x', fontsize=16)
            plt.ylabel('y', fontsize=16)
            plt.grid()
            plt.plot(xx[0:n_x * NN:n_x, :].T, xx[1:n_x * NN:n_x, :].T)

            plt.axis('equal')

            plt.show(block=False)
            plt.pause(0.1)
            if tt < Tmax - dt - 1:
                plt.clf()
        plt.show()
        if tt == 1:
           plt.savefig('initial_condition')


class Agent(Node):

    def __init__(self):
        super().__init__('agent',
                         allow_undeclared_parameters=True,
                         automatically_declare_parameters_from_overrides=True)

        # Get parameters from launcher

        self.max_iters = self.get_parameter('max_iters').value
        self.communication_time = self.get_parameter('communication_time').value

        # Desired position for agents. In order: a square, an octagon
        self.N_AGENTS = self.get_parameter('N_AGENTS').value
        Target_Pos = self.get_parameter('Target_Pos').value
        self.Target_Pos = np.array(Target_Pos).reshape(self.N_AGENTS, 2)

        Adj_matrix = self.get_parameter('Adj_matrix').value
        self.Adj_matrix = np.array(Adj_matrix).reshape(self.N_AGENTS, self.N_AGENTS)

        self.tt = 0

        self.timer = self.create_timer(self.communication_time, self.timer_callback)

    def timer_callback(self):
        # Stop the node if tt exceeds MAXITERS
        if self.tt > self.max_iters+2000:
            print("\nPLOTTING BEACH!!")
            PlotCsv(self.Adj_matrix, self.Target_Pos)
            sleep(10)  #  [seconds]
            self.destroy_node()

        # update iteration counter
        self.tt += 0.8


def main(args=None):
    rclpy.init(args=args)

    agent = Agent()
    print("Plotting -- Waiting for Agents Ending")
    sleep(0.5)
    print("GO!")
    try:
        rclpy.spin(agent)
    except KeyboardInterrupt:
        print("----- Node stopped cleanly -----")
    finally:
        rclpy.shutdown()


if __name__ == '__main__':
    main()

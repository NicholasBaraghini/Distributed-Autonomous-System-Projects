from time import sleep
import numpy as np
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray as msg_float


# Take in agent_id, set the first two to leaders and the last two to followers
def formation_update(dt, x_i, neigh, data, kp, kv, Target_Positions, agent_id, type, N_F):
    """
          dt    = discretization step
          x_i   = state pf agent i
          neighbours = list of neighbors
          data  = state of neighbors
          kp  = position gain
          kv  = velocity gain
          Target_Position = positions to be reached to reach the designed formation pattern
          agent_id = Agent identifier
          type = Agent role :[leader or follower]
          N_F = Number of follower

    """
    ka = 0.33

    # define my x(t+1) of agent i
    x_tplus_i = np.zeros(6)
    # Initialize the vector input
    U_ij = np.zeros(2)
    K_i = np.zeros((2, 2))
    # Extract the position vector of agent i
    pp_i = np.array(x_i[0:2])
    # Extract the velocity vector of agent i
    vv_i = np.array(x_i[2:4])

    for j in neigh:
        # Extract the positions and velocities of the neighbours of agent i, without the time dimension (first
        # element of the vector)
        x_j = np.array(data[j].pop(0)[1:])

        if type == 'follower':
            # convert to array everything
            pp_j = np.array(x_j[0:2])
            vv_j = np.array(x_j[2:4])
            aa_j = np.array(x_j[4:6])

            # Definition of the bearing vector taken from the paper :
            g_ij_star = Target_Positions[j, 0:2] - Target_Positions[agent_id, 0:2]
            # g_ij_star[1] = Target_Positions[j, 1] - Target_Positions[agent_id, 1]
            g_ij_norm = np.linalg.norm(g_ij_star)
            g_ij = np.array([g_ij_star]) / (g_ij_norm + 0.001)

            # Bearing Orthogonal Projection Matrix
            P_g_ij_star = np.identity(2) - g_ij.T @ g_ij  # Left associate
            DistanceCorrection = ((pp_i - pp_j) * kp + (vv_i - vv_j) * kv) - aa_j * ka
            K_i += P_g_ij_star

            U_ij += -np.matmul(P_g_ij_star, DistanceCorrection)  # Format [p_x,p_y,v_x,v_y]. U is acceleration

        else:
            PG = 1  # Proportional Gain
            IG = 3  # Integral Gain
            # Implement a position control over the leader to reach the desired position
            pp_target = Target_Positions[agent_id, 0:2]
            PositionControl = (pp_target - pp_i) * PG + (0 - vv_i) * IG
            U_ij += PositionControl

        # Saturation on the control Input
        U_ij[U_ij > 2e2] = 2e2
        U_ij[U_ij < -2e2] = -2e2

    if type == 'follower':
        K_iinv = np.linalg.inv(K_i)
        U_ij = np.matmul(K_iinv, U_ij)

    # Forward Euler.
    # Discretization of the dynamics of agent i
    x_tplus_i[0:2] = pp_i + dt * vv_i
    x_tplus_i[2:4] = vv_i + dt * U_ij
    x_tplus_i[4:6] = U_ij
    return x_tplus_i


def writer(file_name, string):
    """
      inner function for logging
    """
    file = open(file_name, "a")  # "a" is for append
    file.write(string)
    file.close()


class Agent(Node):

    def __init__(self):
        super().__init__('agent',
                         allow_undeclared_parameters=True,
                         automatically_declare_parameters_from_overrides=True)

        # Get parameters from launcher
        self.agent_id = self.get_parameter('agent_id').value
        self.neigh = self.get_parameter('neigh').value

        x_i = self.get_parameter('x_init').value
        self.n_x = len(x_i)
        self.x_i = np.array(x_i)

        self.max_iters = self.get_parameter('max_iters').value
        self.communication_time = self.get_parameter('communication_time').value

        self.kp = self.get_parameter('kp').value
        self.kv = self.get_parameter('kv').value

        # Desired position for agents
        self.N_AGENTS = self.get_parameter('N_AGENTS').value
        self.N_FOLLOWERS = self.get_parameter('N_FOLLOWERS').value

        Target_Pos_1 = self.get_parameter('Target_Pos_1').value
        self.Target_Pos_1 = np.array(Target_Pos_1).reshape(self.N_AGENTS, 2)

        Target_Pos_2 = self.get_parameter('Target_Pos_2').value
        self.Target_Pos_2 = np.array(Target_Pos_2).reshape(self.N_AGENTS, 2)

        Target_Pos_3 = self.get_parameter('Target_Pos_3').value
        self.Target_Pos_3 = np.array(Target_Pos_3).reshape(self.N_AGENTS, 2)

        self.type = self.get_parameter('type').value

        self.tt = 0

        # create logging file
        self.file_name = "letter_csv_file/agent_{}.csv".format(self.agent_id)
        file = open(self.file_name, "w+")  # 'w+' needs to create file and open in writing mode if doesn't exist
        file.close()

        # initialize subscription dict
        self.subscriptions_list = {}

        # create a subscription to each neighbor
        for j in self.neigh:
            topic_name = '/topic_{}'.format(j)
            self.subscriptions_list[j] = self.create_subscription(
                msg_float,
                topic_name,
                lambda msg, node=j: self.listener_callback(msg, node),
                20  # Queue size for messages
            )

        # create the publisher
        self.publisher_ = self.create_publisher(
            msg_float,
            '/topic_{}'.format(self.agent_id),
            50  # Queue size for messages
        )

        self.timer = self.create_timer(self.communication_time, self.timer_callback)

        # initialize a dictionary with the list of received messages from each neighbor j [a queue]
        self.received_data = {j: [] for j in self.neigh}

        print("Setup of agent {} complete".format(self.agent_id))

    def listener_callback(self, msg, node):
        self.received_data[node].append(list(msg.data))

    def timer_callback(self):
        # Perform Consensus
        # Initialize a message of type float
        msg = msg_float()

        if self.tt == 0:  # Let the publisher start at the first iteration
            msg.data = [float(self.tt)]

            # for element in self.x_i:
            #     msg.data.append(float(element))
            [msg.data.append(float(element)) for element in self.x_i]

            self.publisher_.publish(msg)
            self.tt += 1

            # log files
            # 1) visualize on the terminal
            string_for_logger = [round(i, 4) for i in msg.data.tolist()[1:]]
            # print("Iter = {} \t Value = {}".format(int(msg.data[0]), string_for_logger))
            print(f'it : {int(msg.data[0])}')
            # 2) save on file
            data_for_csv = msg.data.tolist().copy()
            data_for_csv = [str(round(element, 4)) for element in data_for_csv[1:5]]
            data_for_csv = ','.join(data_for_csv)
            writer(self.file_name, data_for_csv + '\n')

        else:  # Have all messages at time t-1 arrived?
            # Check if lists are nonempty
            all_received = all(
                self.received_data[j] for j in self.neigh)  # check if all neighbors' have been received
            sync = False

            # print(f"Receiving Status : {all_received}")

            # Have all messages at time t-1 arrived?
            if all_received:
                sync = all(self.tt - 1 == self.received_data[j][0][0] for j in self.neigh)  # True if all True
                # print(f" Synchronization : {sync}")

            if sync:
                DeltaT = self.communication_time
                if self.tt < (self.max_iters /3):
                    self.x_i = formation_update(DeltaT, self.x_i, self.neigh, self.received_data, self.kp, self.kv,
                                                self.Target_Pos_1, self.agent_id, self.type, self.N_FOLLOWERS)

                elif self.tt > (self.max_iters/ 3) and self.tt < (self.max_iters * 2 / 3):
                    self.x_i = formation_update(DeltaT, self.x_i, self.neigh, self.received_data, self.kp, self.kv,
                                                self.Target_Pos_2, self.agent_id, self.type, self.N_FOLLOWERS)
                else:
                    self.x_i = formation_update(DeltaT, self.x_i, self.neigh, self.received_data, self.kp, self.kv,
                                                self.Target_Pos_3, self.agent_id, self.type, self.N_FOLLOWERS)

                # publish the updated message
                msg.data = [float(self.tt)]
                [msg.data.append(float(element)) for element in self.x_i]
                self.publisher_.publish(msg)

                # save data on csv file
                data_for_csv = msg.data.tolist().copy()
                data_for_csv = [str(round(element, 4)) for element in data_for_csv[1:5]]
                data_for_csv = ','.join(data_for_csv)
                writer(self.file_name, data_for_csv + '\n')

                string_for_logger = [round(i, 4) for i in msg.data.tolist()[1:]]
                print("Iter = {} \t Value = {}".format(int(msg.data[0]), string_for_logger))

                # Stop the node if tt exceeds MAXITERS
                if self.tt > self.max_iters:
                    print("\nMAXITERS reached")
                    sleep(3)  #  [seconds]
                    self.destroy_node()

                # update iteration counter
                self.tt += 1


def main(args=None):
    rclpy.init(args=args)

    agent = Agent()
    print("Agent {:d} -- Waiting for sync.".format(agent.agent_id))
    sleep(0.5)
    print("GO!")
    try:
        rclpy.spin(agent)
    except KeyboardInterrupt:
        print("----- Node stopped cleanly -----")
    finally:
        rclpy.shutdown()


if __name__ == '__main__':
    main()
